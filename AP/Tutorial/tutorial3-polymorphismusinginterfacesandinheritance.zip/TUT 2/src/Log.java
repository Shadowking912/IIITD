public class Log implements Function, Compute {

    private final double base;

    public Log(double base) {
        this.base = base;
    }

    @Override
    public double compute(double input) {
        return Math.log10(input) / Math.log10(base);
    }

    @Override
    public Compute differential() {
//        1/(input * Math.log(base))
        return new Divide(new Constant(1), new Multiply(new Power(1), new Constant(Math.log(base))));
    }

    @Override
    public Compute integral() {
//        input * Math.log(input) - input/Math.log(base)
        return new Subtract(new Multiply(new Power(1), new Log(base)), new Divide(new Power(1), new Constant(Math.log(base))));
    }

    @Override
    public String toString() {
        return "log("+base+",x)";
    }
}
