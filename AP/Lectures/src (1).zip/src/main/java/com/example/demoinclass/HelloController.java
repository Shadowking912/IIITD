package com.example.demoinclass;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;

public class HelloController {
    @FXML
    private Label welcomeText;

    @FXML
    protected void onHelloButtonClick() {
        welcomeText.setText("Welcome to JavaFX Application!");
    }

    @FXML
    Label disp;

    long num1;
    String op;
    boolean st=true;

    @FXML
    void dispalynumbers(ActionEvent e){
        if(st)
        {
            disp.setText("");
            st=false;
        }
        String num=((Button)e.getSource()).getText();
        disp.setText(disp.getText()+num);

    }
    @FXML
    void dispalyoperators(ActionEvent e){
        String opt=((Button)e.getSource()).getText();
        if (!opt.equals("=")){
            num1=Long.parseLong(disp.getText());
            op=opt;
            disp.setText("");
        }else{
            long num2=Long.parseLong(disp.getText());
            System.out.println(num1);
            System.out.println(num2);
            float out=calculate(num1,num2,op);
            disp.setText(String.valueOf(out));
            st=true;
            num1=0;
        }
    }

    @FXML
    void reset(){
        st=true;
        num1=0;
        disp.setText("");

    }
    float calculate(long n1,long n2,String op){
        switch (op){
            case "+":
                return n1+n2;
            case "-":
                return n1-n2;
            case "*":
                return n1*n2;
            case "/":
                return n1/n2;
        }
      return 0;
    }
}