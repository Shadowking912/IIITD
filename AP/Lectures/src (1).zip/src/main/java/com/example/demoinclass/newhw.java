package com.example.demoinclass;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;

public class newhw extends Application {
    public static void main(String[] args){

        launch(args);
    }

    @Override
    public void start(Stage stage) throws Exception {

        Button btn=new Button("btn");
        Label lbl= new Label();
        btn.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                lbl.setText("Hello!");
            }
        });


        StackPane sp=new StackPane();

        sp.getChildren().addAll(btn,lbl);


        Scene sc=new Scene(sp);
        stage.setScene(sc);
        stage.show();
    }
}
