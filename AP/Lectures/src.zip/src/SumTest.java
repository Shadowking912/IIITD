import org.junit.*;

import static org.junit.Assert.*;

public class SumTest {
    static Sum mySum;
    @BeforeClass // since memory allocation is costly, @BeforeClass is being used.
    public static void setup(){
        mySum=new Sum(1,1);
    }

    @After// To ensure that the mySum values are set to the original ones after sumexp Testcase
    public void setup2(){
        mySum.var1=1;
        mySum.var2=1;
    }

    @Test
    public void sum() throws InterruptedException {

        int sum = mySum.sum();
        //Thread.sleep(500);
        assertEquals(2,sum);
    }



    @Test(expected = ArithmeticException.class)
    public void sumexp() {
        mySum.var1=51;
        mySum.var2=51;
        int sum = mySum.sum();

    }



    @Test
    public void change_obj() {
        Sum sum = mySum.change_obj();
        assertEquals(mySum,sum);
    }

    @Test
    public void testEquals() {
        Sum mySum2 = new Sum(1, 1);

        assertEquals(mySum,mySum2);
    }
    @AfterClass
    public static void teardown(){
        System.out.println("Tests are completed");
    }
}