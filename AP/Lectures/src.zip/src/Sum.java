public class Sum {
    int var1;
    int var2;
    Sum(int v1,int v2){
        var1=v1;
        var2=v2;
    }
    int sum() throws ArithmeticException{

        int ty=var1+var2;
        if (ty>100){
            throw new ArithmeticException("more than 100");
        }

        return ty;
    }

    Sum change_obj(){
        Sum db=new Sum(this.var1,this.var2);
        //this.var1=12;

        return db;
    }
    @Override
    public boolean equals(Object o) {
        if(o!=null && getClass()==o.getClass()) {
            Sum s = (Sum) o;
            return ((var1==s.var1)&&(var2==s.var2));
        }
        return false;
    }


    @Override
    public String toString() {
        return "Sum{" +
                "var1=" + var1 +
                ", var2=" + var2 +
                '}';
    }
}

