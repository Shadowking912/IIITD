import org.junit.Test;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertSame;
public class testcases {

    @Test
    public void testSum() {
        Sum mySum = new Sum(1, 1);
        int sum = mySum.sum();
        assertFalse(sum>10);
    }
    @Test
    public void testchangeobj() {

        Sum mySum = new Sum(10, 10);
        Sum vb=mySum.change_obj();
        assertEquals(mySum,vb);

    }

}

