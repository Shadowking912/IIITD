

def function1():
     ## name of the function could be changed
     pass

def generateData():

     ##Must call function1
     ## inside it

     pass
