
##This file must use 'cases.py'
## as well as the function, generateData()
## inside it

def function2():
     ##This function is similar
     ## to function 1 but
     ## must be implemented differently
     pass



def testing():
     ##This function must use
     ## input output text file pairs generated earlier
     ## to read the data and test them on the
     ##results from function2

